#!/bin/bash

a=$(date +%Y-%m-%d)

mkdir /tmp/${a}

cp -r . /tmp/${a}
