#!/bin/bash

echo "tudo é ousado a quem nada se atreve"
